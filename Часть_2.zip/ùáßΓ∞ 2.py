import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QLabel
import requests
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt


def get_map(lat, lon, z):
    response = None
    map_request = f"http://static-maps.yandex.ru/1.x/?ll={lon},{lat}8&l=map&z={z}"
    response = requests.get(map_request)

    if not response:
        print("Ошибка выполнения запроса:")
        print(map_request)
        print("Http статус:", response.status_code, "(", response.reason, ")")
        return False
    map_file = "map.png"
    with open(map_file, "wb") as file:
        file.write(response.content)
    return True
 
class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('main.ui',self)
        self.show_map.clicked.connect(self.render_map)
        self.image = QLabel(self)
        self.image.move(162, 8)
        self.image.resize(600, 450)
        self.zoom = 1

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_PageUp:
            if self.zoom < 19:
                self.zoom += 1
        if event.key() == Qt.Key_PageDown:
            if self.zoom > 1:
                self.zoom -= 1
        self.size_z.setValue(self.zoom)

        

    def render_map(self):
        try:
            lat = float(self.lat.value())
            lon = float(self.lon.value())
            self.zoom = int(self.size_z.value())
        except Exception as e:
            print(e)
        suc = get_map(lat, lon, self.zoom)
        if suc:
            self.pixmap = QPixmap('map.png')
            self.image.setPixmap(self.pixmap)
        else:
            print("Error")
        
 

app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())
