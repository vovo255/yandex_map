import sys
import os
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QLabel
import requests
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PIL import Image
import math


def calc_distance(a, b):
    degree_to_meters_factor = 111 * 1000
    a_lon, a_lat = a
    b_lon, b_lat = b
    radians_lattitude = math.radians((a_lat + b_lat) / 2.)
    lat_lon_factor = math.cos(radians_lattitude)
    dx = abs(a_lon - b_lon) * degree_to_meters_factor * lat_lon_factor
    dy = abs(a_lat - b_lat) * degree_to_meters_factor
    distance = math.sqrt(dx * dx + dy * dy)

    return distance


def get_organization(lon, lat):
    search_api_server = "https://search-maps.yandex.ru/v1/"
    api_key = "dda3ddba-c9ea-4ead-9010-f43fbc15c6e3"
    address_ll = f"{lon},{lat}"
    text = f"{lon},{lat}"
    search_params = {
        "apikey": api_key,
        "text": "Аптека",
        "lang": "ru_RU",
        "ll": address_ll,
        "type": "biz"
    }
    response = requests.get(search_api_server, params=search_params)
    if not response:
        return None

    json_response = response.json()
    organization = json_response["features"][0]
    org_name = organization["properties"]["CompanyMetaData"]["name"]
    org_address = organization["properties"]["CompanyMetaData"]["address"]
    point = organization["geometry"]["coordinates"]
    org_point = "{0},{1}".format(point[0], point[1])
    dist = calc_distance((lon, lat), (float(point[0]), float(point[1])))
    print(dist)
    if dist < 50:
        return float(point[0]), float(point[1])
    return None


def coords_geocoder(obj_name):
    geocoder_request = f"http://geocode-maps.yandex.ru/1.x/?apikey=40d1649f-0493-4b70-98ba-98533de7710b&geocode={obj_name}&format=json"
    response = requests.get(geocoder_request)
    if response:
        json_response = response.json()
        toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
        toponym_address = toponym["metaDataProperty"]["GeocoderMetaData"]["text"]
        try:
            index = toponym["metaDataProperty"]["GeocoderMetaData"]["Address"]["postal_code"]
        except Exception as e:
            index = ''
            print(e)
        toponym_coordinates = toponym["Point"]["pos"]
        return toponym_coordinates, toponym_address, index


def get_object_address(lat, lon):
    geocoder_request = f"http://geocode-maps.yandex.ru/1.x/?apikey=40d1649f-0493-4b70-98ba-98533de7710b&geocode={lon},{lat}&format=json"
    response = requests.get(geocoder_request)
    if response:
        json_response = response.json()
        toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
        toponym_address = toponym["metaDataProperty"]["GeocoderMetaData"]["text"]
        toponym_coordinates = toponym["Point"]["pos"]
        return toponym_coordinates, toponym_address


def get_map(lat, lon, z, typ, mt=None):
    response = None
    if mt is None:
        map_request = f"http://static-maps.yandex.ru/1.x/?ll={lon},{lat}&l={typ}&z={z}"
    else:
        map_request = f"http://static-maps.yandex.ru/1.x/?ll={lon},{lat}&l={typ}&z={z}&pt={mt}"
    response = requests.get(map_request)

    if not response:
        return False
    map_file = 'map.png'
    try:
        os.remove(map_file)
    except Exception:
        pass
    with open(map_file, "wb") as file:
        file.write(response.content)
    try:
        im = Image.open(map_file)
        im.convert('RGBA')
        im.save(map_file)
    except Exception:
        pass
    return True


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('main.ui',self)
        self.show_map.clicked.connect(self.render_map)
        self.type_box.activated[str].connect(self.change_map_type)
        self.objS.clicked.connect(self.render_object)
        self.objReset.clicked.connect(self.reset_object)
        self.size_z.valueChanged.connect(self.render_map)
        self.isIndex.stateChanged.connect(self.render_object)
        self.image = QLabel(self)
        self.image.move(162, 8)
        self.image.resize(600, 450)
        self.zoom = 15
        self.latP = 0
        self.lonP = 0
        self.type_of_map = 'map'
        self.mt = None
        self.address = ''
        self.render_map()

    def mousePressEvent(self, event):
        try:
            QApplication.focusWidget().clearFocus()
        except Exception:
            pass
        try:
            x = event.x()
            y = event.y()
            if x in range(162, 763) and y in range(8, 459):
                if event.button() == Qt.LeftButton:
                    x = x - 162
                    y = y - 8
                    center_x = 300
                    center_y = 225
                    px_x = 360 / 2 ** (self.zoom + 8)
                    px_y = 180 / 2 ** (self.zoom + 8)
                    dF_x = (x - center_x) * px_x
                    dF_y = (y - center_y) * px_y
                    self.lonP += dF_x
                    self.latP -= dF_y
                    self.lon.setValue(self.lonP)
                    self.lat.setValue(self.latP)
                    self.mt = f'{self.lonP},{self.latP},pm2rdm'
                    coords, address = get_object_address(self.latP, self.lonP)
                    self.objName.setText(address)
                    self.render_object()
                elif event.button() == Qt.RightButton:
                    x = x - 162
                    y = y - 8
                    center_x = 300
                    center_y = 225
                    px_x = 360 / 2 ** (self.zoom + 8)
                    px_y = 180 / 2 ** (self.zoom + 8)
                    dF_x = (x - center_x) * px_x
                    dF_y = (y - center_y) * px_y
                    lon_ok = self.lonP + dF_x
                    lat_ok = self.latP - dF_y
                    a = get_organization(lon_ok, lat_ok)
                    if not a is None:
                        self.lonP = a[0]
                        self.latP = a[1]
                        self.lon.setValue(self.lonP)
                        self.lat.setValue(self.latP)
                        coords, address = get_object_address(self.latP, self.lonP)
                        self.objName.setText(address)
                        self.render_object()
                        self.mt = f'{self.lonP},{self.latP},pm2rdm'
                
        except Exception as e:
            print(e)

    def change_map_type(self, text):
        if text == 'Карта':
            self.type_of_map = 'map'
        elif text == 'Спутник':
            self.type_of_map = 'sat'
        elif text == 'Гибрид':
            self.type_of_map = 'sat,skl'
        self.render_map()

    def reset_object(self):
        self.mt = None
        self.objName.clear()
        self.address = ''
        self.addressOut.clear()
        self.isIndex.setChecked(False)
        self.render_map()

    def render_object(self):
        try:
            index = ''
            obj = self.objName.text()
            obj_coords, address, index = coords_geocoder(obj)
            lat, lon = map(float, obj_coords.split())
            self.latP = lon
            self.lonP = lat
            self.lat.setValue(lon)
            self.lon.setValue(lat)
            self.mt = f'{lat},{lon},pm2rdm'
            self.address = address
            if self.isIndex.isChecked() and index:
                self.address += f', {index}'
            self.addressOut.setText(self.address)
            self.render_map()
        except Exception as e:
            print(e)

    def keyPressEvent(self, event):
        self.zoom = self.size_z.value()
        if event.key() == Qt.Key_PageUp:
            if self.zoom < 19:
                self.zoom += 1
            self.size_z.setValue(self.zoom)
        if event.key() == Qt.Key_PageDown:
            if self.zoom > 1:
                self.zoom -= 1
            self.size_z.setValue(self.zoom)
        if event.key() == Qt.Key_Down:
            deltaF = round(((180 / 2 ** (self.zoom + 8)) * 450), 5)
            if self.latP - deltaF > -90:
                self.latP -= deltaF
                self.lat.setValue(self.latP)
        if event.key() == Qt.Key_Up:
            deltaF = round(((180 / 2 ** (self.zoom + 8)) * 450), 5)
            if self.latP + deltaF < 180:
                self.latP += deltaF
                self.lat.setValue(self.latP)
        if event.key() == Qt.Key_Left:
            deltaF = round(((360 / 2 ** (self.zoom + 8)) * 600), 5)
            if self.lonP - deltaF > -180:
                self.lonP -= deltaF
                self.lon.setValue(self.lonP)
        if event.key() == Qt.Key_Right:
            deltaF = round(((360 / 2 ** (self.zoom + 8)) * 600), 5)
            if self.lonP + deltaF < 180:
                self.lonP += deltaF
                self.lon.setValue(self.lonP)

        self.render_map()

    def render_map(self):
        self.latP = float(self.lat.value())
        self.lonP = float(self.lon.value())
        self.zoom = int(self.size_z.value())
        suc = get_map(self.latP, self.lonP, self.zoom, self.type_of_map, self.mt)
        if suc:
            self.pixmap = QPixmap('map.png')
            self.image.setPixmap(self.pixmap)

        else:
            print("Error")


app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())
