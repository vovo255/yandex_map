import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QLabel
import requests
from PyQt5.QtGui import QPixmap


def get_map(lat, lon, z):
    response = None
    map_request = f"http://static-maps.yandex.ru/1.x/?ll={lon},{lat}8&l=map&z={z}"
    response = requests.get(map_request)

    if not response:
        print("Ошибка выполнения запроса:")
        print(map_request)
        print("Http статус:", response.status_code, "(", response.reason, ")")
        return False
    map_file = "map.png"
    with open(map_file, "wb") as file:
        file.write(response.content)
    return True
 
class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('main.ui',self)
        self.show_map.clicked.connect(self.render_map)
        self.image = QLabel(self)
        self.image.move(162, 8)
        self.image.resize(600, 450)
        

    def render_map(self):
        try:
            print(2)
            lat = float(self.lat.value())
            lon = float(self.lon.value())
            size = int(self.size_z.value())
            print(1)
        except Exception as e:
            print(e)
        suc = get_map(lat, lon, size)
        print(3)
        if suc:
            self.pixmap = QPixmap('map.png')
            self.image.setPixmap(self.pixmap)
        else:
            print("Error")
        
 

app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())
