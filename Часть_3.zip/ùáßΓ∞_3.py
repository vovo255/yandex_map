import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QLabel
import requests
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt


def get_map(lat, lon, z):
    response = None
    map_request = f"http://static-maps.yandex.ru/1.x/?ll={lon},{lat}8&l=map&z={z}"
    response = requests.get(map_request)

    if not response:
        print("Ошибка выполнения запроса:")
        print(map_request)
        print("Http статус:", response.status_code, "(", response.reason, ")")
        return False
    map_file = "map.png"
    with open(map_file, "wb") as file:
        file.write(response.content)
    return True


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('main.ui',self)
        self.show_map.clicked.connect(self.render_map)
        self.image = QLabel(self)
        self.image.move(162, 8)
        self.image.resize(600, 450)
        self.zoom = 1
        self.latP = 0
        self.lonP = 0

    def mousePressEvent(self, event):
        try:
            QApplication.focusWidget().clearFocus()
        except Exception:
            pass

    def keyPressEvent(self, event):
        self.zoom = self.size_z.value()
        if event.key() == Qt.Key_PageUp:
            if self.zoom < 19:
                self.zoom += 1
            self.size_z.setValue(self.zoom)
        if event.key() == Qt.Key_PageDown:
            if self.zoom > 1:
                self.zoom -= 1
            self.size_z.setValue(self.zoom)
        if event.key() == Qt.Key_Down:
            deltaF = round(((180 / 2 ** (self.zoom + 8)) * 450), 5)
            if self.latP - deltaF > -90:
                self.latP -= deltaF
                self.lat.setValue(self.latP)
        if event.key() == Qt.Key_Up:
            deltaF = round(((180 / 2 ** (self.zoom + 8)) * 450), 5)
            if self.latP + deltaF < 180:
                self.latP += deltaF
                self.lat.setValue(self.latP)
        if event.key() == Qt.Key_Left:
            deltaF = round(((360 / 2 ** (self.zoom + 8)) * 600), 5)
            if self.lonP - deltaF > -180:
                self.lonP -= deltaF
                self.lon.setValue(self.lonP)
        if event.key() == Qt.Key_Right:
            deltaF = round(((360 / 2 ** (self.zoom + 8)) * 600), 5)
            if self.lonP + deltaF < 180:
                self.lonP += deltaF
                self.lon.setValue(self.lonP)

        self.render_map()

    def render_map(self):
        self.latP = float(self.lat.value())
        self.lonP = float(self.lon.value())
        self.zoom = int(self.size_z.value())
        suc = get_map(self.latP, self.lonP,self.zoom)
        if suc:
            self.pixmap = QPixmap('map.png')
            self.image.setPixmap(self.pixmap)
        else:
            print("Error")


app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())
